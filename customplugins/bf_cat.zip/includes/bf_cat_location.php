<?php
// define for manage location for add, edit, delete
function location_faq() {
	global $wpdb;
	$state_list = array('AL'=>"Alabama",  
						'AK'=>"Alaska",  
						'AZ'=>"Arizona",  
						'AR'=>"Arkansas",  
						'CA'=>"California",  
						'CO'=>"Colorado",  
						'CT'=>"Connecticut",  
						'DE'=>"Delaware",  
						'DC'=>"District Of Columbia",  
						'FL'=>"Florida",  
						'GA'=>"Georgia",  
						'HI'=>"Hawaii",  
						'ID'=>"Idaho",  
						'IL'=>"Illinois",  
						'IN'=>"Indiana",  
						'IA'=>"Iowa",  
						'KS'=>"Kansas",  
						'KY'=>"Kentucky",  
						'LA'=>"Louisiana",  
						'ME'=>"Maine",  
						'MD'=>"Maryland",  
						'MA'=>"Massachusetts",  
						'MI'=>"Michigan",  
						'MN'=>"Minnesota",  
						'MS'=>"Mississippi",  
						'MO'=>"Missouri",  
						'MT'=>"Montana",
						'NE'=>"Nebraska",
						'NV'=>"Nevada",
						'NH'=>"New Hampshire",
						'NJ'=>"New Jersey",
						'NM'=>"New Mexico",
						'NY'=>"New York",
						'NC'=>"North Carolina",
						'ND'=>"North Dakota",
						'OH'=>"Ohio",  
						'OK'=>"Oklahoma",  
						'OR'=>"Oregon",  
						'PA'=>"Pennsylvania",  
						'RI'=>"Rhode Island",  
						'SC'=>"South Carolina",  
						'SD'=>"South Dakota",
						'TN'=>"Tennessee",  
						'TX'=>"Texas",  
						'UT'=>"Utah",  
						'VT'=>"Vermont",  
						'VA'=>"Virginia",  
						'WA'=>"Washington",  
						'WV'=>"West Virginia",  
						'WI'=>"Wisconsin",  
						'WY'=>"Wyoming");
	
	$action = (isset($_GET["action"])) ? strtolower($_GET["action"]) : "";
	$action = (isset($_POST["action"])) ? strtolower($_POST["action"]) : $action;	
	
	if ($action == "delete") {
		$sql = "DELETE FROM ". $wpdb->prefix."bf_cat_location WHERE location_id=".clean_var($_GET['location_id']);
		$wpdb->query($sql);
				
		delete_product_type_relation(BF_TYPE_LOCATION, $_GET['location_id']);
		delete_location_state($_GET['location_id']);
				
		echo '<div class="updated"><p><strong>' . __("Location deleted successfully.", "product") . '</strong></p></div>';
		$action = "";
	}
	
	if (isset($_POST["save"])) {
		$sql = $wpdb->prefix."bf_cat_location SET 
			location_name				='" . clean_var($_POST['location_name']) . "',
			location_description		='" . clean_var($_POST['location_description']) . "',
			location_type 				='" . clean_var($_POST['location_type']) . "',
			location_store_finder_url	='" . clean_var($_POST['location_store_finder_url']) . "',
			location_online_sales_url	='" . clean_var($_POST['location_online_sales_url']) . "',									
			location_status				='" . clean_var($_POST['location_status']) . "'";
			
		$location_id = (isset($_POST["location_id"])) ? (int)$_POST["location_id"] : '';
		
		$sql = ($location_id) ? "UPDATE " . $sql . " WHERE location_id = " . $location_id : "INSERT INTO " . $sql;
		$wpdb->query($sql);
		
		$new_entry = 0;
		// delete the previous location and products which is associated wdith particular product
		if($location_id != 0) {
			delete_location_state($location_id);		
			delete_product_type_relation(BF_TYPE_LOCATION, $location_id);			
		}
		else {
			$location_id = $wpdb->insert_id;
			$new_entry = 1;			
		}		
		
		//save location and products which is associated wdith particular product
		save_location_state($_POST['states'], $location_id);				
		save_product_relation($_POST['products'], BF_TYPE_LOCATION, $location_id);
		
		$title = ($new_entry) ? __('Location added successfully','product') : __('Location updated successfully','product');
		echo '<div class="updated"><p><strong>' . $title . '.</strong></p></div>';
		$action = "";
	}
	
	if ($action == "edit") {
		$sql = "SELECT * FROM ". $wpdb->prefix."bf_cat_location WHERE location_id=".clean_var($_GET['location_id']);
		
		// load all the particular location values		
		$location_row 				= $wpdb->get_row($sql);
		$location_name 				= display_var($location_row->location_name);		
		$location_description   	= display_editor_text($location_row->location_description);		
		$location_type				= display_var($location_row->location_type);
		$location_store_finder_url 	= display_var($location_row->location_store_finder_url);
		$location_online_sales_url 	= display_var($location_row->location_online_sales_url);
		$location_status 			= display_var($location_row->location_status);				
	}
	if ($action) {
      ?>
	<div class="wrap">
    <?php if($action == 'add') { ?>
	   <h2><?php _e('Add Location','product'); ?></h2>    
    <?php } else { ?>
	   <h2><?php _e('Edit Location','product'); ?></h2>
    <?php } ?>       
	<?php $location_id = $_REQUEST['location_id']; ?>

	<form name="locationform" id="locationform" class="wrap" method="post" action="<?php echo BF_CAT_ADMIN_URL; ?>?page=bf-cat-location" onsubmit="return location_validate()">
	<input type="hidden" name="location_id" value="<?php echo (int)$location_id ?>" />

    <table cellpadding="5" cellspacing="5" width="70%">
    <tr>
    <td valign="top" width="20%"><span class="required">*</span><label><?php _e('Name','location'); ?>:</label></td>
    <td><input type="text" name="location_name" class="input" size="70" value="<?php echo $location_name; ?>" /></td>
    </tr>                    
   <tr>
    <td valign="top" class="middle_td"><label><?php _e('Description','location'); ?>:</label></td>
    <td>
   <?php the_editor($location_description, $id = 'location_description', '', $media_buttons = false, $tab_index = 2); ?>   </td>
    </tr>
    <tr>
    <td><label><?php _e('Type','location'); ?>:</label></td>
    <td>
    <select name="location_type" id="location_type">
    <option value="Retail">Retail</option>
    <option value="Online">Online</option>                    
    </select>
    <script type="text/javascript">
    document.getElementById('location_status').value = '<?php echo $location_status;?>';
    </script>    </td>
    </tr>
    <tr>
    <td><label><?php _e('Store Finder URL','location'); ?>:</label></td>
    <td><input type="text" name="location_store_finder_url" class="input" size="70" value="<?php echo $location_store_finder_url; ?>" /></td>
    </tr>
    <tr>
    <td><label><?php _e('Online Sales URL','location'); ?>:</label></td>
    <td><input type="text" name="location_online_sales_url" class="input" size="70" value="<?php echo $location_online_sales_url; ?>" /></td>
    </tr>
    <tr>
    <td><label><?php _e('Status','location'); ?>:</label></td>
    <td>
    <select name="location_status" id="location_status">
    <option value="1"><?php echo BF_STATUS_PUBLISHED;?></option>
    <option value="0"><?php echo BF_STATUS_UNPUBLISHED;?></option>                    
    </select>
    <script type="text/javascript">
    document.getElementById('location_status').value = '<?php echo $location_status;?>';
    </script>    </td>
    </tr> 
     <tr>
       <td valign="top">Locations:</td>
       <td valign="top"><?php 	   
		$state_array = '';
		if($location_id != 0) {
			$state_array = get_location_array($location_id);
		}
		   
	   location_listbox($state_list, $state_array);?></td>
     </tr>
     <tr>
    <td valign="top">Products:</td>
    <td valign="top">
    <?php 
    $product_array = '';
    if($location_id != 0) {
        $product_array = get_product_array(BF_TYPE_LOCATION, $location_id);
    }
	
    product_listbox($product_array);?>    </td>
  </tr>      
    </table>
	                      
  <input type="submit" name="save" class="button bold" value="<?php _e('Save','product'); ?> &raquo;" /> <a class="cancel" href="<?php echo BF_CAT_ADMIN_URL; ?>?page=bf-cat-location">Cancel</a>
	    </form>
	</div>
<?php
}
if (!$action) { ?>
<div class="wrap">
<h2><?php _e('Manage Location','product'); ?> <a class="add-new-h2" href="<?php echo BF_CAT_ADMIN_URL; ?>?page=bf-cat-location&action=add">Add New</a></h2>
<?php   // We pull the testimonials from the database	    	
	
    $locations = $wpdb->get_results("SELECT * FROM ". $wpdb->prefix."bf_cat_location ORDER BY location_id ASC");
	
	 if ($locations) {
	     ?>
		<table class="widefat page fixed" width="50%" cellpadding="3" cellspacing="3">
			<thead> 
				<tr>
					<th class="manage-column" scope="col" width="50px"><?php _e('ID','product') ?></th>
					<th class="manage-column" scope="col"><?php _e('Name','product') ?></th>
					<th class="manage-column" scope="col"><?php _e('Location Type','product') ?></th>
					<th class="manage-column" scope="col"><?php _e('Status','product') ?></th>                    
					<th class="manage-column" scope="col"><?php _e('Edit','product') ?></th>
					<th class="manage-column" scope="col"><?php _e('Delete','product') ?></th>
				</tr>
			</thead>
		
	       <?php
	       $class = '';
		   
	       foreach ( $locations as $location ) {
		   $class = ($class == 'alternate') ? '' : 'alternate';
	         echo '<tr class="' .  $class . '">
		     <th scope="row">' . $location->location_id . '</th>
		     <td>' . display_var($location->location_name) . '</td>
			 <td>' . display_var($location->location_type) . '</td>
			 <td>' . display_status($location->location_status) . '</td>			 
		     <td><a href="' . BF_CAT_ADMIN_URL . '?page=bf-cat-location&amp;action=edit&amp;location_id=' . $location->location_id . 
			 '" class="edit">' . __('Edit','product') . '</a></td>';
		  
	         	echo '<td><a href="' . BF_CAT_ADMIN_URL . '?page=bf-cat-location&amp;action=delete&amp;location_id=' . $location->location_id . 
					'" class="delete" onclick="return confirm(\'' . __('Are you sure you want to delete this location?','location') . '\');">' .
					 __('Delete','product') . '</a></td>';
	       
			 echo '</tr>';
	      }
		  echo '</table>';
	} else {
	     echo '<p>'.__('There are no location in the database!','product').'</p>';
	   }
	   echo '</div></div>';
	}
}

// create location listbox with state list
function location_listbox($state_list, $state_array) {
	global $wpdb;
	?>
	<select name="states[]" multiple="multiple" class="listbox">
    <?php 
	foreach ( $state_list as $key => $state ) {
	$selected = '';
	if(location_in_array_field($key, $state_array))
		$selected = 'selected="selected"';
	?>
	<option <?php echo $selected;?> value="<?php echo $key;?>"><?php echo display_var($state);?></option>
    <?php 		
	}
	?>
    </select>
    <?php     
}

// checking location_id of particular product array
function location_in_array_field($needle, $states) {
	if(!empty($states))
	{
		foreach ( $states as $state ) {
			$state = $state->state;
			if($state == $needle)
			{
				return true;
			}
		}
	}	
    return false;
} 

// get all states of particular location
function get_location_array($location_id)
{
	global $wpdb;
	$states = $wpdb->get_results("SELECT state FROM ". $wpdb->prefix."bf_cat_location_states WHERE location_id = '$location_id'");
	$i= 0;
	return $states;
}

// delete all states of particular location
function delete_location_state($location_id) {
	global $wpdb;
	$sql = "DELETE FROM ". $wpdb->prefix."bf_cat_location_states WHERE location_id = '$location_id'";		
	$wpdb->query($sql);
}

// save the states of particular location
function save_location_state($states, $location_id) {
	global $wpdb;
	$count = count($states);
	$i = 0;
	
	while($i < $count)
	{
		$state = $states[$i];
		if($state != '')
		{
			$sql = "INSERT INTO ". $wpdb->prefix."bf_cat_location_states(location_id, state) VALUES ('$location_id', '$state')";			
			$wpdb->query($sql);
		}	
		$i++;
	}
}

?>