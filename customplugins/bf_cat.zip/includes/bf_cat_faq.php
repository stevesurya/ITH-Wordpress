<?php
// define for manage faq for add, edit, delete
function product_faq() {
	global $wpdb;
	$action = (isset($_GET["action"])) ? strtolower($_GET["action"]) : "";
	$action = (isset($_POST["action"])) ? strtolower($_POST["action"]) : $action;
	
	if ($action == "delete") {
		$sql = "DELETE FROM ". $wpdb->prefix."bf_cat_faq WHERE faq_id=".clean_var($_GET['faq_id']);
		$wpdb->query($sql);
	
		delete_product_type_relation(BF_TYPE_FAQ, $_GET['faq_id']);
	
		echo '<div class="updated"><p><strong>' . __("FAQ deleted successfully.", "product") . '</strong></p></div>';
		$action = "";
	}
	
	if (isset($_POST["save"])) {
		$sql = $wpdb->prefix."bf_cat_faq SET 
			faq_status	 ='" . clean_var($_POST['faq_status']) . "',
			faq_answer	 ='" . clean_var($_POST['faq_answer']) . "',
			faq_question ='" . clean_var($_POST['faq_question']) . "'";
			
		$faq_id = (isset($_POST["faq_id"])) ? (int)$_POST["faq_id"] : '';
		
		$sql = ($faq_id) ? "UPDATE " . $sql . " WHERE faq_id = " . $faq_id : "INSERT INTO " . $sql;
		$wpdb->query($sql);

		$new_entry = 0;
		
		if($faq_id != 0) {
			delete_product_type_relation(BF_TYPE_FAQ, $faq_id);			
		}
		else {
			$faq_id = $wpdb->insert_id;
			$new_entry = 1;
		}		
		
		save_product_relation($_POST['products'], BF_TYPE_FAQ, $faq_id);		
		
		$title = ($new_entry) ? __('FAQ added successfully','product') : __('FAQ updated successfully','product');
		echo '<div class="updated"><p><strong>' . $title . '.</strong></p></div>';
		$action = "";
	}
	
	if ($action == "edit") {
		$sql = "SELECT * FROM ". $wpdb->prefix."bf_cat_faq WHERE faq_id=".clean_var($_GET['faq_id']);
		$faq_row = $wpdb->get_row($sql);
		$faq_question = display_var($faq_row->faq_question);		
		$faq_answer   = display_editor_text($faq_row->faq_answer);		
		$faq_status   = display_var($faq_row->faq_status);
	}
	if ($action) {
      ?>
	<div class="wrap">
	   <?php if($action == 'add') { ?>
           <h2><?php _e('Add FAQ','product'); ?></h2>    
       <?php } else { ?>
	   <h2><?php _e('Edit FAQ','product'); ?></h2>
       <?php } ?>
       <?php $faq_id = $_REQUEST['faq_id']; ?>
	    <form name="faqform" id="faqform" class="wrap" method="post" action="<?php echo BF_CAT_ADMIN_URL; ?>?page=bf-cat-faq"  onsubmit="return faq_validate()">
	                <input type="hidden" name="faq_id" value="<?php echo (int)$faq_id ?>" />
	               
					<table cellpadding="5" cellspacing="5" width="70%">
	                <tr>
					<td valign="top" width="10%"><span class="required">*</span><label><?php _e('Question','faq'); ?>:</label></td>
<td><input type="text" name="faq_question" class="input" size="70" value="<?php echo $faq_question; ?>" /></td>
					</tr>
                    
                    <tr>
					<td  class="middle_td" valign="top"><label><?php _e('Answer','faq'); ?>:</label></td>
<td><?php the_editor($faq_answer, $id = 'faq_answer', '', $media_buttons = false, $tab_index = 2); ?></td>
					</tr>
                    
 <tr>
					<td><label><?php _e('Status','faq'); ?>:</label></td>
	                <td>
                    <select name="faq_status" id="faq_status">
                    <option value="1"><?php echo BF_STATUS_PUBLISHED?></option>
                    <option value="0"><?php echo BF_STATUS_UNPUBLISHED?></option>
                    </select>
                    <script type="text/javascript">
					document.getElementById('faq_status').value = '<?php echo $faq_status;?>';
					</script>
                    </td>
					</tr>                    
                     <tr>
                    <td valign="top">Products:</td>
                    <td valign="top">
                    <?php 
                    $product_array = '';
                    if($faq_id != 0) {
                        $product_array = get_product_array(BF_TYPE_FAQ, $faq_id);
                    }
                        
                    product_listbox($product_array);?>
                    </td>
                  </tr>      
				</table>
	            <input type="submit" name="save" class="button bold" value="<?php _e('Save','product'); ?> &raquo;" /> 
                <a class="cancel" href="<?php echo BF_CAT_ADMIN_URL; ?>?page=bf-cat-faq">Cancel</a>
	    </form>
	</div>
<?php
}
if (!$action) { ?>
<div class="wrap">
<h2><?php _e('Manage FAQ','product'); ?> <a class="add-new-h2" href="<?php echo BF_CAT_ADMIN_URL; ?>?page=bf-cat-faq&action=add">Add New</a></h2>
<?php   // We pull the faqs from the database	    	
	
    $faqs = $wpdb->get_results("SELECT * FROM ". $wpdb->prefix."bf_cat_faq ORDER BY faq_id ASC");
	
	 if ($faqs) {
	     ?>
		<table class="widefat page fixed" width="50%" cellpadding="3" cellspacing="3">
			<thead> 
				<tr>
					<th class="manage-column" scope="col" width="50px"><?php _e('ID','product') ?></th>
					<th class="manage-column" scope="col"><?php _e('Question','product') ?></th>
					<th class="manage-column" scope="col"><?php _e('Status','product') ?></th>
					<th class="manage-column" scope="col"><?php _e('Edit','product') ?></th>
					<th class="manage-column" scope="col"><?php _e('Delete','product') ?></th>
				</tr>
			</thead>
		
	       <?php
	       $class = '';
	       foreach ( $faqs as $faq ) {
		   $class = ($class == 'alternate') ? '' : 'alternate';
	         echo '<tr class="' .  $class . '">
		     <th scope="row">' . $faq->faq_id . '</th>
		     <td>' . display_var($faq->faq_question) . '</td>
			 <td>' . display_status($faq->faq_status) . '</td>
		     
		     <td><a href="' . BF_CAT_ADMIN_URL . '?page=bf-cat-faq&amp;action=edit&amp;faq_id=' . $faq->faq_id . 
			 '" class="edit">' . __('Edit','product') . '</a></td>';
		  
	         	echo '<td><a href="' . BF_CAT_ADMIN_URL . '?page=bf-cat-faq&amp;action=delete&amp;faq_id=' . $faq->faq_id . 
					'" class="delete" onclick="return confirm(\'' . __('Are you sure you want to delete this faq?','product') . '\');">' .
					 __('Delete','product') . '</a></td>';
	       
			 echo '</tr>';
	      }
		  echo '</table>';
	} else {
	     echo '<p>'.__('There are no faqs in the database!','product').'</p>';
	   }
	   echo '</div></div>';
	}
}
?>