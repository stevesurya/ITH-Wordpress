<?php
// define for manage testimonial for add, edit, delete
function bf_cat_testimonial() {
	global $wpdb;
	$action = (isset($_GET["action"])) ? strtolower($_GET["action"]) : "";
	$action = (isset($_POST["action"])) ? strtolower($_POST["action"]) : $action;	
	
	if ($action == "delete") {
		$sql = "DELETE FROM ". $wpdb->prefix."bf_cat_testimonial WHERE testimonial_id=".clean_var($_GET['testimonial_id']);
		$wpdb->query($sql);
		
		delete_product_type_relation(BF_TYPE_TESTIMONIAL, $_GET['testimonial_id']);
		
		echo '<div class="updated"><p><strong>' . __("Testimonial deleted successfully.", "product") . '</strong></p></div>';
		$action = "";
	}
	
	if (isset($_POST["save"])) {
		$sql = $wpdb->prefix."bf_cat_testimonial SET 
			testimonial			='" . clean_var($_POST['testimonial']) . "',
			testimonial_status	='" . clean_var($_POST['testimonial_status']) . "',
			testimonial_name	='" . clean_var($_POST['testimonial_name']) . "'";
			
		$testimonial_id = (isset($_POST["testimonial_id"])) ? (int)$_POST["testimonial_id"] : '';
		
		$sql = ($testimonial_id) ? "UPDATE " . $sql . " WHERE testimonial_id = " . $testimonial_id : "INSERT INTO " . $sql;
		$wpdb->query($sql);
		
		$new_entry = 0;
		
		if($testimonial_id != 0) {
			delete_product_type_relation(BF_TYPE_TESTIMONIAL, $testimonial_id);			
		}
		else {
			$testimonial_id = $wpdb->insert_id;
			$new_entry = 1;
		}		
		
		save_product_relation($_POST['products'], BF_TYPE_TESTIMONIAL, $testimonial_id);
		
		$title = ($new_entry) ? __('Testimonial added successfully','product') : __('Testimonial updated successfully','product');
		echo '<div class="updated"><p><strong>' . $title . '.</strong></p></div>';
		$action = "";
	}
	
	if ($action == "edit") {
		$sql = "SELECT * FROM ". $wpdb->prefix."bf_cat_testimonial WHERE testimonial_id=".clean_var($_GET['testimonial_id']);
		$testimonial_row 	= $wpdb->get_row($sql);
		
		$testimonial 		= display_var($testimonial_row->testimonial);		
		$testimonial_name   = display_var($testimonial_row->testimonial_name);		
		$testimonial_status = display_var($testimonial_row->testimonial_status);
	}
	if ($action) {
      ?>

<div class="wrap">
  <?php if($action == 'add') { ?>
  <h2>
    <?php _e('Add Testimonial','product'); ?>
  </h2>
  <?php } else { ?>
  <h2>
    <?php _e('Edit Testimonial','product'); ?>
  </h2>
  <?php } 
  $testimonial_id = $_REQUEST['testimonial_id']; ?>
  
  <form name="testimonialform" id="testimonialform" class="wrap" method="post" action="<?php echo BF_CAT_ADMIN_URL; ?>?page=bf-cat-testimonial" onsubmit="return testimonial_validate()">
    <input type="hidden" name="testimonial_id" value="<?php echo (int)$testimonial_id ?>" />
    <table cellpadding="5" cellspacing="5">
      <tr>
        <td><span class="required">*</span><label><?php _e('Testimonial','testimonial'); ?>:</label></td>
        <td><input type="text" name="testimonial" class="input" size="70" value="<?php echo $testimonial; ?>" /></td>
      </tr>
      <tr>
        <td><label><?php _e('Name','testimonial'); ?>:</label></td>
        <td><input type="text" name="testimonial_name" class="input" size="70" value="<?php echo $testimonial_name; ?>" /></td>
      </tr>     
      <tr>
        <td><label><?php _e('Status','testimonial'); ?>:</label></td>
        <td><select name="testimonial_status" id="testimonial_status">
            <option value="1"><?php echo BF_STATUS_PUBLISHED?></option>
            <option value="0"><?php echo BF_STATUS_UNPUBLISHED?></option>
          </select>
          <script type="text/javascript">
				document.getElementById('testimonial_status').value = '<?php echo $testimonial_status;?>';
		  </script>
        </td>
      </tr>
	  <tr>
        <td valign="top">Products:</td>
        <td valign="top">
        <?php 
		$product_array = '';
		// this condition will work on edit form and load product_array all the product_id which is associated with particular testimonial
		if($testimonial_id != 0) {
			$product_array = get_product_array(BF_TYPE_TESTIMONIAL, $testimonial_id);
		}
		
		// load active product listbox
		product_listbox($product_array);?>        
        </td>
      </tr>      
    </table>
    
  <input type="submit" name="save" class="button bold" value="<?php _e('Save','product'); ?> &raquo;" /> <a class="cancel" href="<?php echo BF_CAT_ADMIN_URL; ?>?page=bf-cat-testimonial">Cancel</a>
  </form>
</div>
<?php
}
if (!$action) { ?>
<div class="wrap">
<h2>
  <?php _e('Manage Testimonial','product'); ?>
  <a class="add-new-h2" href="<?php echo BF_CAT_ADMIN_URL; ?>?page=bf-cat-testimonial&action=add">Add New</a></h2>
<?php   // We pull the testimonials from the database	    	
	
    $testimonials = $wpdb->get_results("SELECT * FROM ". $wpdb->prefix."bf_cat_testimonial ORDER BY testimonial_id ASC");
	
	 if ($testimonials) {
	     ?>
<table class="widefat page fixed" width="50%" cellpadding="3" cellspacing="3">
<thead>
  <tr>
    <th class="manage-column" scope="col" width="50px"><?php _e('ID','product') ?></th>
    <th class="manage-column" scope="col"><?php _e('Question','product') ?></th>
    <th class="manage-column" scope="col"><?php _e('Status','product') ?></th>
    <th class="manage-column" scope="col"><?php _e('Edit','product') ?></th>
    <th class="manage-column" scope="col"><?php _e('Delete','product') ?></th>
  </tr>
</thead>
<?php
	       $class = '';
	       foreach ( $testimonials as $testimonial ) {
		   $class = ($class == 'alternate') ? '' : 'alternate';
		   
		   if($testimonial->testimonial_status == 1) {
		   		$testimonial_status = BF_STATUS_PUBLISHED;
		   }
		   else {
			   $testimonial_status = BF_STATUS_UNPUBLISHED;
		   }
		   
	         echo '<tr class="' .  $class . '">
		     <th scope="row">' . $testimonial->testimonial_id . '</th>
		     <td>' . display_var($testimonial->testimonial) . '</td>
			 <td>' . display_status($testimonial->testimonial_status) . '</td>
		     
		     <td><a href="' . BF_CAT_ADMIN_URL . '?page=bf-cat-testimonial&amp;action=edit&amp;testimonial_id=' . $testimonial->testimonial_id . 
			 '" class="edit">' . __('Edit','product') . '</a></td>';
		  
	         	echo '<td><a href="' . BF_CAT_ADMIN_URL . '?page=bf-cat-testimonial&amp;action=delete&amp;testimonial_id=' . $testimonial->testimonial_id . 
					'" class="delete" onclick="return confirm(\'' . __('Are you sure you want to delete this testimonial?','product') . '\');">' .
					 __('Delete','product') . '</a></td>';
	       
			 echo '</tr>';
	      }
		  echo '</table>';
	} else {
	     echo '<p>'.__('There are no testimonial in the database!','product').'</p>';
	   }
	   echo '</div></div>';
	}
}
?>