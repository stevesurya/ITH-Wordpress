<?php


function product_image_input($id) {
	global $wpdb;
	$count = 0;
	// Load the images
	echo '<div class="imagesortable">';
	$wpdb->show_errors();
	$images = $wpdb->get_results("SELECT * FROM " . WP_PRODUCT_IMAGES_TABLE . " WHERE product_id=" . (int)$id . "");
	
	
	
	// Loop through the images
	foreach ($images as $image) {	;
		// Output the field for each existing
		if ($image->product_image) {
			product_image_field($count, $image->product_image);
			$count++;
		}
	}	
	// Output one more new one
	product_image_Field($count);
	echo '<input type="hidden" name="productimagesort" value="" id="productimagesort" />';
	echo '</div>';
	echo ($count > 1) ? '<p class="imagesortnotice">Drag and drop images to change their sort order</p>' : '';
}

function product_image_field($count, $src="") {

	echo '<div class="product_images">';
	echo '<div class="imagecontainer" id="product-div-' . $count . '">';
	if ($src) {
		echo '<img class="image-upload" id="product-image-' . $count . '" src="' . $src . '" />';
		echo '<a href="javascript:removeImage(' . $count . ');" class="delete" id="product-delete-' . $count . '" title="Click to remove image">X</a>';
	}
	echo '</div>';
       	echo '<a href="media-upload.php?post_id=0&type=image&TB_iframe=1&width=640&height=673" data-count="' . $count . '" id="product-link-' . $count . '" class="image-upload">Add New Image</a>';
       	echo '<input type="hidden" name="image[' . $count . ']" value="' . $src . '" id="product-field-' . $count . '" />';
       	echo '</div>';
}

function product_do_Thumb($image, $size="full", $url = "") {
	global $shownImages;
	$class = (!$url) ? ' class="inv_lightbox"' : '';
	$url = ($url) ? $url : 'javascript:void(0);';
	/**
	 *  
	 * This function is to return a slider / "lightbox" functionality if there's a thumb/full-size combo of images.
	 * First, it checks the directory to see if there's any naming conventions that match
	 * image.jpg -> sm_image.jpg (sm_image.jpg is thumb, image is full size)
	 * lg_image.jpg -> sm_image.jpg (sm_image.jpg is thumb, lg_image is full size)
	 * lg_image.jpg -> image.jpg (lg_image.jpg is full, image.jpg is thumb)
	 * image.jpg -> image_large.jpg (image is thumb, image_large.jpg is full size)
	 * image_small.jpg -> image_large.jpg (image_small is thumb, image_large is full size)
	 * 
	 **/
	
	$in_uploads = (stripos($image, "/uploads/") !== false) ? true : false;
	if ($in_uploads) {
		$image_dir = "";
		$full_image = $image;
		$base = substr($image, strripos($image, "/") + 1);
		$ext = substr($base, stripos($base, "."));
		$base = substr($base, 0, strripos($base, "."));
		if (stripos($base, "-")!==false && stripos($base, "x")!==false) {
			$base = substr($base, 0, strripos($base, "-")) . $ext;
			$image = substr($image, 0, strripos($image, "/") + 1) . $base;
		}
		global $wpdb, $table_prefix;
		$images = $wpdb->get_results("SELECT ID FROM " . $table_prefix . "posts WHERE guid='" . inv_db_res($image) . "'");
		if ($images) {
			$image = $images[0];
			$thumb_image = wp_get_attachment_image_src($image->ID, $size);
			$thumb_image = $thumb_image[0];
			$med_image = wp_get_attachment_image_src($image->ID, "medium");
			$med_image = $med_image[0];
			$large_image = wp_get_attachment_image_src($image->ID, "large");
			$large_image = $large_image[0];
		}
	} else {
		$image_dir = PRODUCT_IMAGE_DIR . '/';
		// LEGACY code in place for previous inventories
		if (is_array($shownImages)) {
			if (in_array(strtolower($image), $shownImages))  {
				return "";
			}
		}
		
		$shownImages[] = strtolower($image);
		
		$prefixes = array("sm_", "lg_", "lrg_", "small_", "large_", "thumb_");
		$suffixes = array("_sm", "_lg", "lrg_", "_small", "_large", "_thumb");
		$ext = substr($image, strrpos($image, "."));
		$image_name = substr($image, 0, strlen($image)-strlen($ext));
		$image_base = $type = "";
		// Find base-name
		
		// Look for prefixes first
		foreach ($prefixes as $prefix) {
			if (strpos(strtolower($image_name), $prefix)===0) {
				$image_base = substr($image_name, strlen($prefix));
				$type = $prefix;
			}
		}
		
		// If no base found, look for suffixes
		if (!$image_base) {
			foreach ($suffixes as $suffix) {
				if (strpos(strtolower($suffix), $prefix)!==false) {
					$image_base = substr($image_name, strlen($prefix));
					$type = $prefix;
				}
			}
		}
		
		if (!$image_base) {$image_base = $image_name;}
		$match = inv_findImageMatch($image, $image_base, $ext);
		
		$shownImages[] = strtolower($match);
		
		// Sort out which image is the full and which is the small
		$small = array("sm_", "_sm", "_small", "small_", "thumb_", "_thumb");
		$images = array($image=>$match, $match=>$image);
		foreach($images as $s=>$f) {
			foreach ($small as $v) {
				if (stripos($s, $v)!==false) {
					$thumb_image = $s;
					$full_image = $f;
					break;
				}
			}
			if (isset($thumb_image) && $thumb_image) {break;}
		}
		
		if (!isset($thumb_image) || !$thumb_image) {
			$small = array("lg_", "_lg", "_large", "large_", "lrg_", "_lrg");
			foreach($images as $s=>$f) {
				foreach ($small as $v) {
					if (stripos($s, $v)!==false) {
						$thumb_image = $s;
						$full_image = $f;
						break;
					}
				}
				if (isset($thumb_image) && $thumb_image) {break;}
			}
		}
		if (isset($thumb_image) && $thumb_image && $full_image) {
			$med_image = (isset($med_image) && $med_image) ? ' data-medium="' . $med_image . '"' : '';
			return '<a' . $class . ' href="' . $url . '" data-large="' . $full_image . '"><img class="inv_image"' . $med_image . ' src="' . PRODUCT_IMAGE_DIR . '/' . $thumb_image . '" title="Click for Larger Image"></a>';
		} else {
			return '<img class="inv_image" src="' . PRODUCT_IMAGE_DIR . '/' . $image . '" title="">';
		}
	}
	if (isset($thumb_image) && $thumb_image && $full_image) {
		$med_image = (isset($med_image) && $med_image) ? ' data-medium="' . $med_image . '"' : '';
		$med_image.= (isset($large_image) && $large_image) ? ' data-large="' . $large_image . '"' : '';
		return '<a' . $class . ' href="' . $url . '" data-full="' . $full_image . '"><img class="inv_image"' . $med_image . ' src="' . $image_dir . $thumb_image . '" title="Click for Larger Image"></a>';
	} else {
		$image = (isset($thumb_image) && $thumb_image) ? $thumb_image : $image;
		$image = (!$image && isset($med_image) && $med_image) ? $med_image : $image;
		$image = (!$image && isset($large_image) && $large_image) ? $large_image : $image;
		$image = (!$image && isset($full_image) && $full_image) ? $full_image : $image;
		return '<img class="inv_image" src="' . $image_dir . $image . '" title="">';
	}
}

function inv_findImageMatch($exist, $base, $ext) {
	$dir = @opendir(PRODUCT_LOAD_FROM);
	$prefixes = array("sm_", "lg_", "lrg_", "small_", "large_", "thumb_", "");
	$suffixes = array("_sm", "_lg", "_lrg", "_small", "_large", "_thumb");
	while ($file = readdir($dir)) {
		if ($file != $exist) {
			foreach ($prefixes as $prefix) {
				if (strtolower($file) == strtolower($prefix . $base . $ext)) {
					return $file;
				}
			}
			foreach ($suffixes as $suffix) {
				if (strtolower($file) == strtolower($base . $suffix . $ext)) {
					return $file;
				}
			}
		}
	}
}

function inv_doImages($key) {
	if (!isset($_FILES[$key])) {
		return "";
	}
	$image = $_FILES[$key];
	$name = $image["name"];
	if ($name) {
		if (!inv_isImage($name)) {
			echo __("Warning! NOT an image file! File not uploaded.", "product");
			return "";
		}
		if (inv_uploadFile($image, $name, PRODUCT_SAVE_TO, true)) {
			return $name;
		} else {
			return false;
		}
	}
	
}

function inv_isImage($file) {
	$imgtypes =array("BMP", "JPG", "JPEG", "GIF", "PNG");
	$ext =strtoupper( substr($file ,strlen($file )-(strlen( $file  ) - (strrpos($file ,".") ? strrpos($file ,".")+1 : 0) ))  ) ;
	if (in_array($ext, $imgtypes)) {
		return true;
	} else {
		return false;
	}
}

?>