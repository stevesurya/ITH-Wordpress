<?php
function bf_cat_product() {
	global $wpdb;
	$action = (isset($_GET["action"])) ? strtolower($_GET["action"]) : "";
	$action = (isset($_POST["action"])) ? strtolower($_POST["action"]) : $action;	
	
	if ($action == "delete") {
		$sql = "DELETE FROM ". $wpdb->prefix."bf_cat_product WHERE product_id=".clean_var($_GET['product_id']);
		$wpdb->query($sql);
						
		echo '<div class="updated"><p><strong>' . __("Product deleted successfully.", "product") . '</strong></p></div>';
		$action = "";
	}
	if (isset($_POST["save"])) {
		$sql = $wpdb->prefix."bf_cat_product SET 
			product_name='" . clean_var($_POST['product_name']) . "',
			product_description='" . clean_var($_POST['product_description']) . "',
			faq_intro='" . clean_var($_POST['faq_intro']) . "',
			label_description='" . clean_var($_POST['label_description']) . "',
			resources='" . clean_var($_POST['resources']) . "',
			testimonials_intro='" . clean_var($_POST['testimonials_intro']) . "',
			buy_intro='" . clean_var($_POST['buy_intro']) . "',			
			product_status='" . clean_var($_POST['product_status']) . "'";
			
		$product_id = (isset($_POST["product_id"])) ? (int)$_POST["product_id"] : '';
		
		$sql = ($product_id) ? "UPDATE " . $sql . " WHERE product_id = " . $product_id : "INSERT INTO " . $sql;
		$wpdb->query($sql);
		
		$title = ($product_id) ? __('Product updated successfully','product') : __('Product added successfully','product');
		echo '<div class="updated"><p><strong>' . $title . '.</strong></p></div>';
		$action = "";
	}
	
	if ($action == "edit") {
		$sql = "SELECT * FROM ". $wpdb->prefix."bf_cat_product WHERE product_id=".clean_var($_GET['product_id']);
		$product_row 	= $wpdb->get_row($sql);
		
		$product_name			= display_var($product_row->product_name);
		$product_description	= display_editor_text($product_row->product_description);
		$product_status			= $product_row->product_status;
		$faq_intro				= display_editor_text($product_row->faq_intro);
		$label_description		= display_editor_text($product_row->label_description);
		$resources				= display_editor_text($product_row->resources);
		$testimonials_intro		= display_editor_text($product_row->testimonials_intro);
		$buy_intro				= display_editor_text($product_row->buy_intro);
	}
	if ($action) {
      ?>
  <div class="wrap">
  <?php if($action == 'add') { ?>
  <h2>
    <?php _e('Add Product','product'); ?>
  </h2>
  <?php } else { ?>
  <h2>
    <?php _e('Edit Product','product'); ?>
  </h2>
  <?php } ?>
  <?php $product_id = $_REQUEST['product_id']; ?>
  <form name="productform" id="productform" class="wrap" method="post" action="<?php echo BF_CAT_ADMIN_URL; ?>?page=bf-cat-product" onsubmit="return product_validate()">
	<input type="hidden" name="product_id" id="product_id" value="<?php echo $product_id; ?>" />
    <table cellpadding="5" cellspacing="5" width="70%">
    <tr><td valign="top"><span class="required">*</span><label>Name:</label></td><td><input type="text" name="product_name" size="60"  value="<?php echo $product_name; ?>" /></td></tr>
    <tr><td valign="top"><label>Product Image:</label></td><td>
	<?php product_image_input($product_id);?> </td></tr>
	<tr><td valign="top"><label>Label Image:</label></td><td></td></tr>
	 <tr><td valign="top"><label>Status:</label></td><td>
					<select name="product_status" id="product_status">
                    <option value="1"><?php echo BF_STATUS_PUBLISHED?></option>
                    <option value="0"><?php echo BF_STATUS_UNPUBLISHED?></option>
                    </select>
                     <script type="text/javascript">
					document.getElementById('product_status').value = '<?php echo $product_status;?>';
					</script>
                    </td></tr>
                  
                    <tr><td valign="top" class="middle_td"><label>Description:</label></td><td>
                    <?php the_editor($product_description, $id = 'product_description', '', $media_buttons = false, $tab_index = 2); ?></td></tr>
                    <tr><td valign="top" class="middle_td"><label>FAQs Intro:</label></td><td>
                <?php the_editor($faq_intro, $id = 'faq_intro', '', $media_buttons = false, $tab_index = 2); ?></td></tr>
                    <tr><td valign="top" class="middle_td"><label>Label Description:</label></td><td>
                    <?php the_editor($label_description, $id = 'label_description', '', $media_buttons = false, $tab_index = 2); ?>
            		</td></tr>
                    
                    <tr><td valign="top" class="middle_td"><label>Resources:</label></td><td>
                      <?php the_editor($resources, $id = 'resources', '', $media_buttons = false, $tab_index = 2); ?></td></tr>
                    <tr><td valign="top" class="middle_td"><label>Testimonials Intro:</label></td><td>
                     <?php the_editor($testimonials_intro, $id = 'testimonials_intro', '', $media_buttons = false, $tab_index = 2); ?></td></tr>
                    <tr><td valign="top" class="middle_td"><label>Where to Buy Intro:</label></td><td>
                    <?php the_editor($buy_intro, $id = 'buy_intro', '', $media_buttons = false, $tab_index = 2); ?>
                    </td></tr>
                    </table>
    <input type="submit" name="save" class="button bold" value="<?php _e('Save','product'); ?> &raquo;" />
    <a class="cancel" href="<?php echo BF_CAT_ADMIN_URL; ?>?page=bf-cat-product">Cancel</a>
 
  </form>
</div>
<?php
}
if (!$action) { ?>
<div class="wrap">
<h2>
  <?php _e('Manage Product','product'); ?>
  <a class="add-new-h2" href="<?php echo BF_CAT_ADMIN_URL; ?>?page=bf-cat-product&action=add">Add New</a></h2>
<?php   // We pull the testimonials from the database	    	
	
    $products = $wpdb->get_results("SELECT * FROM ". $wpdb->prefix."bf_cat_product ORDER BY  product_id ASC");
	
	 if ($products) {
	     ?>
<table class="widefat page fixed" width="50%" cellpadding="3" cellspacing="3">
<thead>
  <tr>
    <th class="manage-column" scope="col" width="50px"><?php _e('ID','product') ?></th>
    <th class="manage-column" scope="col"><?php _e('Name','product') ?></th>
    <th class="manage-column" scope="col"><?php _e('Status','product') ?></th>
    <th class="manage-column" scope="col"><?php _e('Edit','product') ?></th>
    <th class="manage-column" scope="col"><?php _e('Delete','product') ?></th>
  </tr>
</thead>
<?php
	       $class = '';
	       foreach ( $products as $product ) {
		   $class = ($class == 'alternate') ? '' : 'alternate';
		   
		   if($product->product_status == 1) {
		   		$product_status = BF_STATUS_PUBLISHED;
		   }
		   else {
			   $product_status = BF_STATUS_UNPUBLISHED;
		   }
		   
	         echo '<tr class="' .  $class . '">
		     <th scope="row">' . $product->product_id . '</th>
		     <td>' . display_var($product->product_name) . '</td>
			 <td>' . display_status($product->product_status) . '</td>
		     
		     <td><a href="' . BF_CAT_ADMIN_URL . '?page=bf-cat-product&amp;action=edit&amp;product_id=' . $product->product_id . 
			 '" class="edit">' . __('Edit','product') . '</a></td>';
		  
	         	echo '<td><a href="' . BF_CAT_ADMIN_URL . '?page=bf-cat-product&amp;action=delete&amp;product_id=' . $product->product_id . 
					'" class="delete" onclick="return confirm(\'' . __('Are you sure you want to delete this product?','product') . '\');">' .
					 __('Delete','product') . '</a></td>';
	       
			 echo '</tr>';
	      }
		  echo '</table>';
	} else {
	     echo '<p>'.__('There are no product in the database!','product').'</p>';
	   }
	   echo '</div></div>';
	}
}

// create product listbox with products
function product_listbox($product_array) {
	global $wpdb;
	$products = $wpdb->get_results("SELECT * FROM ". $wpdb->prefix."bf_cat_product WHERE product_status = 1 ORDER BY product_id DESC");
	?>
	<select name="products[]" multiple="multiple" class="listbox">
    <?php 
	foreach ( $products as $product ) {
	$selected = '';
	if(product_in_array_field($product->product_id, $product_array))
		$selected = 'selected="selected"';
	?>
	<option <?php echo $selected;?> value="<?php echo $product->product_id;?>"><?php echo display_var($product->product_name);?></option>
    <?php 		
	}
	?>
    </select>
    <?php     
	}
	  
// delete all product id of particular type and type id
function delete_product_type_relation($type, $type_id) {
	global $wpdb;
	$sql = "DELETE FROM ". $wpdb->prefix."bf_cat_relationship WHERE type = '$type' AND type_id = '$type_id'";		
	$wpdb->query($sql);
}

// get all product id of particular type and type id
function get_product_array($type, $type_id) {
	global $wpdb;
	$products = $wpdb->get_results("SELECT product_id FROM ". $wpdb->prefix."bf_cat_relationship WHERE type = $type AND type_id = '$type_id'");
	return $products;
}

// checking product_id of particular product array
function product_in_array_field($needle, $products) {
	
	if(!empty($products))
	{
		foreach ( $products as $product ) {
			$product_id = $product->product_id;
			if($product_id == $needle)
			{
				return true;
			}
		}
	}	
    return false;
}

// save product id of particular type and type id
function save_product_relation($products, $type, $type_id)  {
	global $wpdb;
	$count = count($products);
	$i = 0;
	
	while($i < $count)
	{
		$product_id = $products[$i];
		if($product_id != '')
		{
			$sql = "INSERT INTO ". $wpdb->prefix."bf_cat_relationship(product_id, type, type_id) VALUES ('$product_id', '$type', '$type_id')";
			$wpdb->query($sql);
		}	
		$i++;
	}
}