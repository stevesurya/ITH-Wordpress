var index, formfield, tbframe_interval;
jQuery(function($){
	$('#optiontabs a').click(function() {
		$('#optiontabs a').removeClass('current');
		$(this).addClass('current');
		var id = $(this).attr('id');
		id = id.replace('tab_', '');
		if (id!='all') {
			$('.inv_options').hide('easeOutBounce');
			$('#' + id + '_options').show('easeOutBounce');
		} else {
			$('.inv_options').show('easeOutBounce');
		}
	});
	
	$("#addfield").click(function() {
		var i = $(".product_types tr").size();
		$(".product_types").append(
	'<tr id="custom' + i + '"><td>Custom<input type="hidden" name="field_id[NEW' + i + ']" value="20" /></td><td><input type="text" name="field_label[NEW' + i + ']" value="Custom" /></td><td>' + typeDisplayList(i, "list") + '</td><td>' + typeDisplayList(i, "detail") + '</td><td>' + typeTypeList(i) + '</td><td><input class="types" type="text" name="field_options[NEW' + i + ']" /></td><td><div><a class="delete" href="javascript:deleteCustomField(' + i + ');">X</a></tr>');
	
	});
	
	$("select.display_list").live("change", function() {
		toggleDisplayList($(this));
	}).each(function() {toggleDisplayList($(this));});
	
	
	function toggleDisplayList(el) {
		if (parseInt($(el).val()) < 0) {
			$(el).parents("tr").find("select.display_detail").val(0).prop("disabled", true);
		} else {
			$(el).parents("tr").find("select.display_detail").prop("disabled", false);
		}
	}
	
	function typeDisplayList(i, t) {
		var html = '<select class="display_' + t + '" name="field_display_' + t + '[NEW' + i + ']">';
		html+= '<option value="0">Do Not Display</option>';
		for (var x=1; x<=i; x++) {
			html+='<option value="' + x + '">' + x + '</option>';
		}
		html+= '</select>';
		return html;
	}
	
	function typeTypeList(i) {
		var html = '<select name="field_type[NEW' + i + ']">';
		html+= '<option value="text">Text Input</option>';
		html+= '<option value="textarea">Text Area</option>';
		html+= '<option value="select">Select Dropdown</option>';
		html+= '<option value="radio">Radio Buttons</option>';
		html+= '</select>';
		return html;
	}
	
	$("#product_type_id").change(function() {editItemSwitchType();});
	$(".product_types a.type_help").click(function() {showProductHelp();});
    
	function editItemSwitchType() {
		var typeId = $("#product_type_id").val();
		var itemId = $("#product_id").val();
		var action = $_GET("action");
		window.location = productAJAX.pageurl + '&action=' + action + '&type=' + typeId + '&product_id=' + itemId;
	}
	
	function $_GET(q) {
		var query = window.location.search.substring(1);
		var vars = query.split("&");
		for (var i = 0; i < vars.length; i++) {
			var pair = vars[i].split("=");
			if (pair[0] == q) {
				return unescape(pair[1]);
			}
		}
		return false;
	} 
	
	function showProductHelp() {
		if ($(".inside .product_help").is(":visible")!==false) {
			$(".inside div.product_help").slideUp("fast", function() {$(".inside div.product_help").remove();});
		} else {
			$.post(
				productAJAX.ajaxurl,
				{
				action : 'productTypeHelp'
				},
				function(response) {
					$(".inside").prepend('<div class="product_help">' + response + '</div>');
					$(".inside div.product_help").slideDown();
				}
			);
		}
	}
	
	// Media upload functionality
	$('.image-upload').click(function() {
		productUpload($(this));
		 return false;
	});
	$('.deleteimage').click(function() {
		removeImage($(this).attr("id"));
	});
	window.original_send_to_editor = window.send_to_editor;
	window.send_to_editor = function(html) {
		if (formfield) {
			setTimeout(function() {
				html = '<p>' + html + '</p>';
			 	var imgurl = $('img', html).attr('src');
				$('#product-field-' + formfield).val(imgurl);
				 tb_remove();
				 renderImage(formfield, imgurl);
				 formfield = "";}, 500);
			// Clear the interval that changes the button name
			clearInterval(tbframe_interval);
		// If not, use the ORIGINAL
		} else {
			window.original_send_to_editor(html);
		}
	}
	
	function productUpload(el) {
		 formfield = $(el).attr('data-count');
		 tb_show('', 'media-upload.php?&post_id=0&type=image&TB_iframe=1');
 		 tbframe_interval = setInterval(function() {$('#TB_iframeContent').contents().find('.savesend .button').val('Use This Image');}, 2000);
	}

	/* function to load the image url into the correct input box */
	function renderImage(field, img) {
		if ($("img#product-image-" + field).length <= 0) {
			$("div.#product-div-" + field).prepend('<img id="product-image-' + field + '" src="" />');
			$("div.#product-div-" + field).prepend('<a class="delete" id="product-delete-' + field + '" href="javascript:removeImage(' + field + ')">X</a>');
		}
		$("img#product-image-" + field).attr("src", img);
		$("a#product-link-" + field).html("");
		ensureNewImage();
	}
	
	function ensureNewImage() {
		var empty = 0;
		var count = 0;
		$("div.imagecontainer").each(
			function() {
				count++;
				if ($(this).find("img").length <=0) {
					empty = 1;
				}
			}
		);
		if (!empty) {
			var td = $("div.imagecontainer").parents("div.imagesortable");
			var html = '<div class="product_images">';
			html+= '<div class="imagecontainer" id="product-div-' + count + '"></div>';
			html+= '<a href="media-upload.php?post_id=0&type=image&TB_iframe=1&width=500&height=500" data-count="' + count + '" id="product-link-' + count + '" class="image-upload">Add New Image</a>';
			html+= '<input type="hidden" name="image[' + count + ']" value="" id="product-field-' + count + '" />';
			html+= '</div>';
			td.append(html);
			$('#product-link-' + count).click(function() {
				productUpload($(this));
				 return false;
			});
		}
	}
});

function removeImage(id) {
	jQuery("input#product-field-" + id).val('');
	jQuery("img#product-image-" + id).remove();
	jQuery("a#product-delete-" + id).remove();
	jQuery("a#product-link-" + id).html("Add New Image");
}

function testimonial_validate()
{
	if(document.testimonialform.testimonial.value == '')
	{
		alert("Please enter testimonial");
		document.testimonialform.testimonial.focus();
		return false;
	}
	return true;
}

function faq_validate()
{
	if(document.faqform.faq_question.value == '')
	{
		alert("Please enter question");
		document.faqform.faq_question.focus();
		return false;
	}
	return true;
}

function location_validate()
{
	if(document.locationform.location_name.value == '')
	{
		alert("Please enter name");
		document.locationform.location_name.focus();
		return false;
	}
	return true;
}

function product_validate()
{
	if(document.productform.product_name.value == '')
	{
		alert("Please enter name");
		document.productform.product_name.focus();
		return false;
	}
	return true;
}