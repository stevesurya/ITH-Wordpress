jQuery(function($) {
	$("div.product .product_images .product_thumbs .inv_lightbox").click(
			function() {
				var full = $(this).attr("data-full");
				var lrg = $(this).find("img").attr("data-large");
				var med = $(this).find("img").attr("data-medium");
				var src = lrg;
				if (typeof src == "undefined") {
					src = $(this).find("img").attr("src");
				}
				console.log(full);
				$(this).parents(".product_images").find(".product_main a").attr("data-full", full);
				$(this).parents(".product_images").find(".product_main a img").attr("data-large", lrg);
				$(this).parents(".product_images").find(".product_main img").attr("src", src);
			}
	);
	
	$("div.product .product_main .inv_lightbox").click(
			function() {
				var src = $(this).find("img").attr("data-large");
				console.log(src);
				if (typeof src == "undefined" || !src) {
					return;
				}
				$("#product_lightwrap img").attr("src", src);
				$("#product_blur, #product_lightwrap").fadeIn();
				$("#product_lightbox").css("width", "10px");
				setTimeout(function() {
					var w = $("#product_lightwrap img").width();
					if (w > ($(window).width() - 80)) {
						w = $(window).width() - 80;
						$("#product_lightwrap img").css("width", w + "px");
					}
					$("#product_lightbox").animate({
						width: w + 'px'
					});
				}, 100);
			}
	);
});

function invHideLightbox() {
	jQuery("#product_blur, #product_lightwrap").fadeOut();
	jQuery("#product_lightwrap img").css("width", "auto");
}