<?php
/*
Plugin Name: BF Catalogue
Plugin URI: http://www.bigfresh.com
Description: This plugin allows you to manage products and it's Faqs, Testimonials, Location.
Author: Big Fresh, Inc
Author URI: http://www.bigfresh.com/
Version: 1.0
*/

// define all the constant for used any file
define('BF_CATALOGUE_VERSION', '1.0');
define('BF_STATUS_PUBLISHED', 'Publish');
define('BF_STATUS_UNPUBLISHED', 'Unpublish');
define('BF_TYPE_FAQ', 1);
define('BF_TYPE_TESTIMONIAL', 2);
define('BF_TYPE_LOCATION', 3);
define('WP_PRODUCT_IMAGES_TABLE', $wpdb->prefix. 'bf_product_image');

$adminurl = get_bloginfo('url') . "/wp-admin/admin.php";
define('BF_CAT_ADMIN_URL', $adminurl);

// include all necessary files
require_once "includes/bf_cat_product.php";
require_once "includes/bf_cat_faq.php";
require_once "includes/bf_cat_testimonial.php";
require_once "includes/bf_cat_location.php";
require_once "includes/image_functions.php";

// Create a admin menu for BF Catalogue and its sub-pages
add_action('admin_menu', 'bf_catalogue_menu');

// Add the function that puts style and script information in the admin header
add_action('admin_enqueue_scripts', 'bf_catalogue_admin_scripts');

register_activation_hook(__FILE__, 'bf_cat_install');

global $wnm_db_version;
$wnm_db_version = "1.0";

function bf_cat_install(){
	global $wpdb;	
	require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
		
	$sql = "CREATE TABLE IF NOT EXISTS `". $wpdb->prefix."bf_cat_faq` (
		   `faq_id` int(11) NOT NULL AUTO_INCREMENT,		  
		   `faq_question` text NOT NULL,
		   `faq_answer` text NOT NULL,
		   `faq_status` tinyint(4) NOT NULL,		  
		   PRIMARY KEY (`faq_id`)
		)";
	dbDelta($sql);
	
	$sql = "CREATE TABLE IF NOT EXISTS `". $wpdb->prefix."bf_cat_location` (
		   `location_id` int(11) NOT NULL AUTO_INCREMENT,
		   `location_name` text NOT NULL,
		   `location_description` text NOT NULL,
		   `location_type` varchar(255) NOT NULL,
		   `location_store_finder_url` varchar(255) NOT NULL,
		   `location_online_sales_url` varchar(255) NOT NULL,
		   `location_status` tinyint(4) NOT NULL,
		   PRIMARY KEY (`location_id`))";
	dbDelta($sql);	
	
	$sql = "CREATE TABLE IF NOT EXISTS `". $wpdb->prefix."bf_cat_location_states` (
			`location_id` int(11) NOT NULL,
			`state` varchar(20) NOT NULL)";
	dbDelta($sql);		

	$sql = "CREATE TABLE IF NOT EXISTS `". $wpdb->prefix."bf_cat_product` (
		   `product_id` int(11) NOT NULL AUTO_INCREMENT,
		   `product_name` text,
		   `product_description` mediumtext NOT NULL,		  
		   `faq_intro` text NOT NULL,
		   `label_description` text NOT NULL,
		   `resources` text NOT NULL,
		   `testimonials_intro` text NOT NULL,
		   `buy_intro` text NOT NULL,
		   `product_status` tinyint(4) NOT NULL,		  
		   PRIMARY KEY (`product_id`))";
	dbDelta($sql);		

	$sql = "CREATE TABLE IF NOT EXISTS `". $wpdb->prefix."bf_cat_relationship` (
			`product_id` int(11) NOT NULL,
			`type` int(11) NOT NULL COMMENT 'faq 1, testiominal 2, location 3',
			`type_id` int(11) NOT NULL)";
	dbDelta($sql);		

	$sql = "CREATE TABLE IF NOT EXISTS `". $wpdb->prefix."bf_cat_testimonial` (
		   `testimonial_id` int(11) NOT NULL AUTO_INCREMENT,
		   `testimonial` text NOT NULL,
		   `testimonial_name` text NOT NULL,
		   `testimonial_status` tinyint(4) NOT NULL,		  
		   PRIMARY KEY (`testimonial_id`))";
	dbDelta($sql);		

	$sql = "CREATE TABLE IF NOT EXISTS `". $wpdb->prefix."bf_product_image` (
		   `product_image_id` int(11) NOT NULL AUTO_INCREMENT,
		   `product_id` int(11) NOT NULL,
		   `product_image` text NOT NULL,
		   `type` int(11) NOT NULL COMMENT 'Image 1, Label 2',
		   PRIMARY KEY (`product_image_id`))";
	dbDelta($sql);		
}


// define for admin script and style
function bf_catalogue_admin_scripts() {
	$page = (isset($_GET["page"])) ? $_GET["page"] : '';
	
	// this condition will work for load admin-style.css, admin-script.js in this particular admin pages
	if (stripos($page, "product")!==false || stripos($page, "bf-cat-faq")!==false || stripos($page, "bf-cat-testimonial")!==false || stripos($page, "bf-cat-location")!==false) {
			
		$pluginurl = WP_PLUGIN_URL.'/'.str_replace(basename( __FILE__),"",plugin_basename(__FILE__)); 
		
		wp_register_style('product-admin-style', $pluginurl . '/assets/css/admin-style.css');
		wp_enqueue_style('product-admin-style');
				
		wp_register_script('product-admin-script', $pluginurl . '/assets/js/admin-script.js');
		wp_enqueue_script('product-admin-script');
	}
}

// define for media upload popup script
function bf_catalogue_script() {
	wp_enqueue_script('media-upload');
	wp_enqueue_script('thickbox');
	wp_enqueue_script('jquery');
}

// define for media upload popup style
function bf_catalogue_style() {
	wp_enqueue_style('thickbox');
}

add_action('admin_print_scripts', 'bf_catalogue_script');
add_action('admin_print_styles', 'bf_catalogue_style');

// define for admin script and style
function bf_catalogue_menu()  {
	global $wpdb;
	
	add_menu_page(__('BF Catalogue','bf-cat-product'), __('BF Catalogue','bf-cat-product'), 'manage_options', 'bf-cat-product', 'bf_cat_product');
	add_submenu_page('bf-cat-product', __('Manage Product','bf-cat-product'), __('Manage Product','bf-cat-product'), 'manage_options', 'bf-cat-product', 'bf_cat_product');
	add_submenu_page('bf-cat-product', __('Manage FAQs','bf-cat-product'), __('Manage FAQs','bf-cat-product'), 'manage_options', 'bf-cat-faq', 'product_faq');	   
	add_submenu_page('bf-cat-product', __('Manage Testimonials','bf-cat-product'), __('Manage Testimonials','bf-cat-product'), 'manage_options', 'bf-cat-testimonial', 'bf_cat_testimonial');
	add_submenu_page('bf-cat-product', __('Manage Locations','bf-cat-product'), __('Manage Locations','bf-cat-product'), 'manage_options', 'bf-cat-location', 'location_faq');
}

// define for clean variable for insert and update
function clean_var($val) {
	$val = mysql_real_escape_string($val);
	return $val;
}

// define for clean variable for display
function display_editor_text($val) {
	$val = stripslashes($val);
	return $val;
}

// define for clean variable for display
function display_var($val) {
	$val = stripslashes($val);
	$val = htmlspecialchars($val);	
	return $val;
}

// define for display status on manage form
function display_status($status) {
	if($status == 1)
	return BF_STATUS_PUBLISHED;
	else
	return BF_STATUS_UNPUBLISHED;	
}
?>