<?php

if (defined('WP_UNINSTALL_PLUGIN')) {
	bf_cat_uninstall_product();
}

function bf_cat_uninstall_product() {
	global $wpdb;

	$query = "DROP TABLE " . $wpdb->prefix . "bf_cat_faq";
	$wpdb->query($query);	

	$query = "DROP TABLE " . $wpdb->prefix . "bf_cat_location";
	$wpdb->query($query);	

	$query = "DROP TABLE " . $wpdb->prefix . "bf_cat_location_states";
	$wpdb->query($query);	

	$query = "DROP TABLE " . $wpdb->prefix . "bf_cat_product";
	$wpdb->query($query);	

	$query = "DROP TABLE " . $wpdb->prefix . "bf_cat_relationship";
	$wpdb->query($query);	

	$query = "DROP TABLE " . $wpdb->prefix . "bf_cat_testimonial";
	$wpdb->query($query);	

	$query = "DROP TABLE " . $wpdb->prefix . "bf_product_image";
	$wpdb->query($query);	

}

?>